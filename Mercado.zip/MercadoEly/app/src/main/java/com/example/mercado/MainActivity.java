package com.example.mercado;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btpagar, bttotal;
    CheckBox cbarroz, cbfeijao, cbovo, cbleite, cbgoiabada;
    double total, desconto, valorPago, troco;
    TextView textViewtotal, textViewpagar;
    RadioGroup rdgdesconto;
    RadioButton rbsd, rb5, rb10, rb15;
    EditText editTotal;


    @Override
    protected void onCreate(Bundle SavedInstanceState){
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.activity_main);
        cbarroz = findViewById(R.id.cbarroz) ;
        cbfeijao = findViewById(R.id.cbfeijao);
        cbovo = findViewById(R.id.cbovo);
        cbleite = findViewById(R.id.cbleite);
        cbgoiabada = findViewById(R.id.cbgoiabada);
        btpagar = findViewById(R.id.btpagar);
        //bttotal = findViewById(R.id.bttotal);
        textViewtotal = findViewById(R.id.textViewTotal);
        //textViewpagar = findViewById(R.id.textViewpagar);
        rdgdesconto = findViewById(R.id.rdgDesconto);
        rbsd = findViewById(R.id.rbsemdesconto);
        rb5 = findViewById(R.id.rb5);
        rb10 = findViewById(R.id.rb10);
        rb15 = findViewById(R.id.rb15);
        editTotal = findViewById(R.id.edttotal);
        /*bttotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                total = TotalPrecos();
                textViewtotal.setText(String.format("Total a pagar: $%5.2f",total));
            }
        });//*/
        cbarroz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TotalPrecos();
            }
        });

        cbfeijao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TotalPrecos();

            }
        });

        cbleite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TotalPrecos();
            }
        });

        cbgoiabada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TotalPrecos();
            }
        });

        cbovo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TotalPrecos();
            }
        });
        rbsd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TotalPrecos();
            }
        });

        rb5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TotalPrecos();
            }
        });

        rb10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TotalPrecos();
            }
        });

        rb15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TotalPrecos();
            }
        });
        btpagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double valorPago = Double.parseDouble(editTotal.getText().toString());

                Double troco = valorPago - total;


                AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);

                alerta.setTitle("Confimar pagamento!!");
                //String textoDialogo = String.format("")
                alerta.setMessage(String.format("Valor total da compra:%5.2f\nDeconto recebido: R$%5.2f\n" +
                                "Valor pago:%5.2f\nTroco:%5.2f"
                        ,total, desconto, valorPago, troco));
                alerta.setNeutralButton("OK", null);
                alerta.show();

            }
        });

    }

    public  void TotalPrecos()
    {
        total = 0;
        if (cbarroz.isChecked()){total += 16.49f;}
        if(cbfeijao.isChecked()){total += 6.99f;}
        if(cbovo.isChecked()){total += 14.99f;}
        if(cbleite.isChecked()){total += 6.19f;}
        if(cbgoiabada.isChecked()){total += 3.29f;}

        Double desc = 0.0;

        if(rb5.isChecked()) { desc = 0.05; }
        else if(rb10.isChecked()) { desc = 0.1; }
        else if(rb15.isChecked()) { desc = 0.15; }

        desc = (total * desc);

        desconto = desc;

        total = total -(desc);

        textViewtotal.setText(String.format("TOTAL: R$%5.2f",total));
        //return total;
    }


}