package com.example.localentrega1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.TriggerEvent;
import android.hardware.TriggerEventListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button btnCep, bntatualizar;
    EditText edtCep;
    TextView txtResp;
    RecyclerView rvlista;
    List<DBCep> dbCeps = new ArrayList<>();
    CEPAdapter adapter;
    RecyclerView.LayoutManager layoutManager;

    Sensor acelerometro;
    SensorEventListener  listener;
    SensorManager  sensorManager;

    float valoresGravide[] = new float[3];


    @Override
    protected void onResume(){
        super.onResume();
        sensorManager.registerListener(listener, acelerometro, sensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause(){
       super.onPause();
       sensorManager.unregisterListener(listener);
    }


    @Override
    protected void onStart(){
        atualizarLista();
        super.onStart();
    }

    public void atualizarLista(){

        layoutManager = new LinearLayoutManager(getApplicationContext());
        CEPDAO cepdao = new CEPDAO(getApplicationContext());
        CEPAdapter adapter =  new CEPAdapter(cepdao.listar());
        rvlista = findViewById(R.id.rvLista);
        rvlista.setLayoutManager(layoutManager);
        rvlista.setHasFixedSize(true);
        rvlista.addItemDecoration(new DividerItemDecoration(getApplicationContext(), LinearLayoutManager.VERTICAL));
        rvlista.setAdapter(adapter);
        dbCeps = cepdao.listar();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        rvlista = findViewById(R.id.rvLista);
        txtResp = findViewById(R.id.txtresp);
        btnCep = findViewById(R.id.btnCep);
        bntatualizar = findViewById(R.id.bntatualizar);
        edtCep = findViewById(R.id.edtCep);
        Activity act = this;
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        acelerometro = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        listener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
              if (sensorEvent.values[0] > 16){

                  finish();
              }

            };

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };

        //finish();
        //System.exit(0);


        rvlista.addOnItemTouchListener(
                new RecyclerItemClickListener(
                        getApplicationContext(),
                        rvlista,
                        new RecyclerItemClickListener.OnItemClickListener() {
                            @Override
                            public void onItemClick(View view, int position) {
                                Toast.makeText(getApplicationContext(),dbCeps.get(position).cep,
                                        Toast.LENGTH_LONG).show();
                            }//*/

                            @Override
                            public void onLongItemClick(View view, int position) {

                                Toast.makeText(getApplicationContext(), "Clique longo!", Toast.LENGTH_LONG).show();

                                    AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                                    alertDialog.setTitle("Opcões Avançadas");
                                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Ver no Maps",
                                            new DialogInterface.OnClickListener()
                                            {

                                                public void onClick(DialogInterface dialog, int which)
                                                {

                                                    String address= dbCeps.get(position).logradouro+", "+ dbCeps.get(position).bairro+ " - "+
                                                            dbCeps.get(position).localidade+"/ "+dbCeps.get(position).uf;

                                                    Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
                                                    intent.putExtra("endereco", address);
                                                    startActivity(intent);
                                                   // String

                                                }
                                            });
                                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Apagar Endereço!!",
                                            new DialogInterface.OnClickListener()
                                            {
                                                public void onClick(DialogInterface dialog, int which)
                                                {
                                                    DialogResp dialogResp = new DialogResp();

                                                    dialogResp.YNAlterData("", act, dbCeps.get(position), 2);

                                                }
                                            });

                                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Cancelar",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    dialog.dismiss();
                                                }
                                            });
                                    alertDialog.show();

                            }
                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l){}

                        }
                ) );

        btnCep.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {


                MyTask myTask = new MyTask();
                String urlApi = "https://viacep.com.br/ws/" + edtCep.getText().toString() + "/json/";

                myTask.AddTxtLoading(findViewById(R.id.txtresp), act);
                edtCep.setText("");

                myTask.execute(urlApi);
                txtResp.setText("Carregando");
                }
             });

        bntatualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);

            }
        });

        }

    }



