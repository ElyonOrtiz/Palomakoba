package com.example.localentrega1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CEPAdapter extends RecyclerView.Adapter<CEPAdapter.MyViewHolder> {
    private List<DBCep> dbCeps = new ArrayList<DBCep>();
    public CEPAdapter(List<DBCep> list) {this.dbCeps = list;}

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){

        View itemlista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cep_adpter_view, parent, false);

        return new MyViewHolder(itemlista);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position){
        StringBuilder conjunto = new StringBuilder();
        conjunto.append(this.dbCeps.get(position).logradouro)
                .append("\n")
                .append(this.dbCeps.get(position).localidade)
                .append("\n")
                .append(this.dbCeps.get(position).bairro);
        holder.endereco.setText(conjunto.toString());
        holder.cep.setText(this.dbCeps.get(position).cep);

    }

    @Override
    public int getItemCount() { return this.dbCeps.size();}

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView cep, endereco;

        public MyViewHolder(@NonNull View v) {
            super(v);
            cep = v.findViewById(R.id.txtCeplb);
            endereco = v.findViewById(R.id.txtEnderecolb);
        }
    }

}

