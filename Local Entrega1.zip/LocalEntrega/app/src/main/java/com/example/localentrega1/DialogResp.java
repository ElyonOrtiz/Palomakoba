package com.example.localentrega1;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class DialogResp extends MainActivity {
    Context mContext;

    public DialogResp() {

    }

    public void YNAlterData(String add, Activity act, DBCep cpp, int caso) {
        String title = "";
        String msg = "";

        CEPDAO cepdao = new CEPDAO(act.getBaseContext());

        switch (caso) {
            case 0: //Salvar
            {
                //cepdao.salvar(cpp);
                title = "CEP RETORNADO!";
                msg = add + "\n \n Deseja adicionar o CEP abaixo na sua lista \n \n ";
            }
            break;

            case 1: //Editar / Atualizar
            {
                // cepdao.atualizar(cpp);
                title = "Edição de registro";
                msg = add + "\n \n Deseja Reeditar o CEP abaixo de sua lista \n \n ";
            }
            break;

            case 2: //Deletar/ Excluir
            {
                //cepdao.deletar(cpp);
                title = "Exclusão de registro";
                msg = add + "\n \n Deseja APAGAR o CEP abaixo da sua lista ";
            }
            break;
        }

        AlertDialog.Builder builder;

        builder = new AlertDialog.Builder(act);

        builder.setMessage(msg)
                .setTitle(title)
                .setCancelable(false)
                /*.setPositiveButton("Exibir no Mapa", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        }
                    })//*/
                .setPositiveButton("Salvar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        if(caso == 0)
                        {
                            cepdao.salvar(cpp);

                        }
                        else if(caso == 1)
                        {
                            cepdao.atualizar(cpp);

                            OKDialog("OK","Registro alterado com sucesso!", act);
                        }
                        else if(caso == 2)
                        {
                            cepdao.deletar(cpp);

                            OKDialog("OK","Registro excluído com sucesso!", act);
                        }
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        //  Action for 'NO' Button
                        dialog.cancel();
                    }
                });//*/
        builder.show();

            /*
                //Creating dialog box
            AlertDialog alert = builder.create();
                //Setting the title manually

            alert.setTitle("AlertDialogExample");
            alert.show();//*/
    }

    public void OKDialog(String title, String msg, Activity act)
    {
        AlertDialog.Builder builder;

        builder = new AlertDialog.Builder(act);

        builder.setMessage(msg)
                .setTitle(title)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        builder.show();
    }
}




