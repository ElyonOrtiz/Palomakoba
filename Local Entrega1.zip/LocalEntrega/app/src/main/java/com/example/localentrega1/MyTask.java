package com.example.localentrega1;

import android.app.Activity;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MyTask extends AsyncTask<String, Void, String> {

    //public Mensagem    msn;

    public MainActivity mainActivity;

    private TextView txtResp;

    public Activity act;

    public void AddTxtLoading(TextView ttx, Activity activity) {
        txtResp = ttx;
        act = activity;
    }

    @Override
    protected String doInBackground(String... strings) {
        String stringURL = strings[0];
        InputStream inputStream = null;
        InputStreamReader inputStreamReader = null;
        StringBuffer stringBuffer = new StringBuffer();
        try {
            URL url = new URL(stringURL);
            HttpURLConnection conexao = (HttpURLConnection) url.openConnection();
            inputStream = conexao.getInputStream();
            inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String linha = "";
            while ((linha = reader.readLine()) != null) {
                stringBuffer.append(linha);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuffer.toString();
    }

    @Override
    public void onPostExecute(String s) {
        super.onPostExecute(s);

        DialogResp dialogResp = new DialogResp();
        DBCep dbCep = new DBCep();

        /*String logradouro = null;
        String cep = null;
        String complemento = null;
        String bairro = null;
        String localidade = null;
        String uf = null;
        StringBuilder sb = new StringBuilder();//*/

        StringBuilder sb = new StringBuilder();


        try {
            JSONObject jsonObject = new JSONObject(s);

            dbCep.logradouro = jsonObject.getString("logradouro");
            dbCep.cep = jsonObject.getString("cep");
            dbCep.complemento = jsonObject.getString("complemento");
            dbCep.bairro = jsonObject.getString("bairro");
            dbCep.localidade = jsonObject.getString("localidade");
            dbCep.uf = jsonObject.getString("uf");
            sb.append(dbCep.logradouro).append("\n").append(dbCep.localidade).append("\n").append(dbCep.cep)
                    .append("\n").append(dbCep.complemento).append("\n").append(dbCep.bairro)
                    .append("\n").append(dbCep.uf).append("\n");


        } catch (JSONException e) {
            e.printStackTrace();
        }
        dialogResp.YNAlterData(sb.toString(), act, dbCep, 0);
        //txtResp.setText(sb);
       /* txtResp.setText(sb.toString());
        mainActivity.Msg(sb.toString());

        txtResp.setVisibility(View.INVISIBLE);//*/
        //Log.i("test", "até aqui funcionando");
        txtResp.setText("");

    }

    public boolean CepValido(String cep) {
        if (cep.length() == 9) {
            return true;
        }
        return false;


    }
}
